import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Cloud extends Actor
{
   private int transparency;
   private int speed;
   
   public Cloud()
   {
       createCloud();
   }
   
   public int getSpeed()
   {
       return speed;
   }
   
   private void createCloud()
   {
       int random = Greenfoot.getRandomNumber(3);
       if(random == 0)
       {
          createCloudOne();
       }       
       else if(random == 1)
       {
          createCloudTwo();
       }       
       else
       {
          createCloudThree();
       }
   }
   
   private void createCloudOne()
   {
        setImage("Cloud1.png");
        speed = Greenfoot.getRandomNumber(4) + 2;
        getImage().setTransparency( Greenfoot.getRandomNumber(25) + 230);
   }
   
   private void createCloudTwo()
   {
        setImage("Cloud2.png");
        speed = Greenfoot.getRandomNumber(8) + 3;
        getImage().setTransparency( Greenfoot.getRandomNumber(100) + 100);
   }
   
    private void createCloudThree()
   {
        setImage("Cloud3.png");
        speed = Greenfoot.getRandomNumber(6) + 3;
        getImage().setTransparency( Greenfoot.getRandomNumber(100) + 155);
        int scaleFactor = Greenfoot.getRandomNumber(3) + 1;
        getImage().scale(getImage().getWidth() * 3, getImage().getHeight() * 3);
   }
}
