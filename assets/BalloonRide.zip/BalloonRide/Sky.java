import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Sky extends World
{
    private Balloon balloon;
    private int starTimer;
    private Bar scoreBar;
    
    public Sky()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(700, 500, 1); 
        starTimer = 20;
        
        setPaintOrder(Bar.class, Spike.class, Balloon.class, Actor.class, Cloud.class);
        
        balloon = new Balloon();
        addObject(balloon, 350, 100);
        
        scoreBar = new Bar("Score: ", 30, 0);
        addObject(scoreBar, 100, 30);

        CloudAnimator.addClouds(this);
    }
    
    public void act()
    {
        CloudAnimator.animateClouds(this);
        scoreBar.setValue(balloon.getScore());
    }    
    
    public void addStar()
    {
        int x = 50;
        int y = 50;
        addObject(getNewStar(), x, y);
    }
    
    private ShootingStar getNewStar()
    {
        return new ShootingStar();    
    }
    
    private void addStarsOnTimer()
    {
        if(starTimer > 0)
        {
            starTimer--;
        }
        else
        {
            addStar();
            starTimer = 10 + Greenfoot.getRandomNumber(50); 
        }
    }
    
}
