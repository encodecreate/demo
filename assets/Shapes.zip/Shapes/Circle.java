import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Circle extends Actor
{
    private int diameter;
    private Color color;
    
    public Circle()
    {
        diameter = 60;
        color = color.RED;
        
        GreenfootImage img = new GreenfootImage(diameter, diameter);
        img.setColor(color);
        img.fillOval( 0, 0, diameter, diameter);
        setImage(img);
    }
    
    public void setDiameter(int diameter)
    {
        this.diameter = diameter;
        redraw();
    }
    
    public void setColor(Color color)
    {
        this.color = color;
        redraw();
    }
    
    public void redraw()
    {
        GreenfootImage img = new GreenfootImage(diameter, diameter);
        img.setColor(color);
        img.fillOval( 0, 0, diameter, diameter);
        setImage(img);
    }
}
