import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Spike here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Spike extends Actor
{
    private boolean movesUp;
    private boolean movesSideways;
    private int speed;
    
    public Spike()
    {
        movesUp = false;
        movesSideways = false;
        speed = 3;
    }
    
    public void canMoveUp()
    {
        movesUp = true;    
    }
    
    public void canMoveSideways()
    {
        movesSideways = true;
    }
    
    public void act()
    {
        move();
    }
    
    public void move()
    {
        if(movesUp)
        {
            moveUp();
        }
        if(movesSideways)
        {
            moveSideways();
        }
    }
    
    public void moveUp()
    {
        setLocation(getX(), getY() + speed);
        if(getY() < 10 || getY() > getWorld().getHeight() - 10)
        {
            speed = speed * -1;
        }
    }
    
    public void moveSideways()
    {
        setLocation(getX() + speed, getY() );
        if(getX() < 10 || getX() > getWorld().getWidth() - 10)
        {
            speed = speed * -1;
        }
    }
    
    public void makeBigger()
    {
        int width = getImage().getWidth();
        int height = getImage().getHeight();
        getImage().scale(3 * width / 2, 3* height / 2);
    }
}
