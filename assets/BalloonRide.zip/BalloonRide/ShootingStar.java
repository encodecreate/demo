import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class ShootingStar extends Actor
{
   protected GifImage star;
   protected int direction;
   protected int points;
   
   public ShootingStar()
   {
       star = new GifImage("ShootingStar.gif");
       points = 1;
   }
   
   public void act()
   {
       fly();
       setImage( star.getCurrentImage() );
       disappear();
   }
   
   public void fly()
   {
       move(3);
       turn(direction / 250);
   }
   
   private void disappear()
   {
       if(isAtEdge())
       {
           getWorld().removeObject(this);
       }
   }
   
   public int getPoints()
   {
       return points;
   }
}
