import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Square extends Actor
{
    private int size;
    private Color color;
    
    public Square() 
    {
        size = 60;
        color = Color.BLUE;
        
        GreenfootImage img = new GreenfootImage(size, size);
        img.setColor(color);
        img.fillRect( 0, 0, size, size);
        setImage(img);
    }
    
    public void changeSize(int size)
    {
        this.size = size;
        redraw();
    }
    
    public void setColor(Color color)
    {
        this.color = color;
        redraw();
    }
    
    public void redraw()
    {
        GreenfootImage img = new GreenfootImage(size, size);
        img.setColor(color);
        img.fillRect( 0, 0, size, size);
        setImage(img);
    }
    
    
    
    
}
