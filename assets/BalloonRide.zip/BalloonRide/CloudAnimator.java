import greenfoot.*;
import java.util.List;
/**
 * Write a description of class OceanAnimator here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class CloudAnimator 
{
    public static Cloud[] createClouds()
    {
        Cloud[] clouds = new Cloud[25];
        for(int i = 0; i < 25; i++)
        {
            clouds[i] = new Cloud();
        }
        return clouds;
    }
    
    public static void addClouds(World world)   
    {
        Cloud[] clouds = createClouds();           
        
        for(Cloud cloud : clouds)
        {
            int y =  Greenfoot.getRandomNumber(world.getHeight());   
            int x = Greenfoot.getRandomNumber(world.getWidth());
            world.addObject(cloud, x, y);
        }
        
    }   
    
    public static void animateClouds(World world)
    {
       List<Cloud> clouds = (List<Cloud>) world.getObjects(Cloud.class);
        
        for(Cloud cloud : clouds)
        {     
            cloud.setLocation(cloud.getX() - cloud.getSpeed(), cloud.getY());
            if(cloud.getX() <= 2)
            {
               cloud.setLocation(world.getWidth(), Greenfoot.getRandomNumber(world.getHeight()));
            }            
        }  
    }
    
   

}
