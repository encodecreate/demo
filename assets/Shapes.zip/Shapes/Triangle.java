import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)


public class Triangle extends Actor
{
    private int height;
    private int width;
    private Color color;
    
    public Triangle()
    {
        height = 70;
        width = 50;
        color = Color.GREEN; 
        
        GreenfootImage img = new GreenfootImage(width, height);
        img.setColor(color);
        int[] xPoints = {0, 0 + width/2, 0 + width};
        int[] yPoints = {height, 0, height};
        
        img.fillPolygon( xPoints, yPoints, 3);
        setImage(img);
    }
    
    public void setWidth(int width)
    {
        this.width = width;
        redraw();
    }
    
    public void setHeight(int height)
    {
        this.height = height;
        redraw();
    }
    
    public void setColor(Color color)
    {
        this.color = color;
        redraw();
    }
    
    public void redraw()
    {
        GreenfootImage img = new GreenfootImage(width, height);
        img.setColor(color);
        int[] xPoints = {0, 0 + width/2, 0 + width};
        int[] yPoints = {height, 0, height};
        
        img.fillPolygon( xPoints, yPoints, 3);
        setImage(img);
    }
}
