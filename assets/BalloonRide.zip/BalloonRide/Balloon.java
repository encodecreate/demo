import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Balloon here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Balloon extends Actor
{
   private int xSpeed;
   private int ySpeed;
   private GreenfootImage balloon;
   private GreenfootImage balloonRising;
   private int score;
   private boolean popped;
   
   public Balloon()
   {
        xSpeed = 2;   
        ySpeed = 1;
        popped = false;
        score = 0;
        balloon = new GreenfootImage("Balloon.png");
        balloonRising = new GreenfootImage("BalloonRising.png");
   }
   
   public void act()
   {
       if(!popped)
       {
           keyCommands();       
           touchStar();
           touchSpike();
           victory();
        }
       pop();
       fall();
   }
    
   public void touchSpike()
   {
       if(isTouching(Spike.class))
       {
           popped = true;
       }
   }
   
   public void moveLeft()
   {
       setLocation(getX() - xSpeed, getY());
   }
   
   public void moveRight()
   {
       setLocation(getX() + xSpeed, getY());
   }
   
   public void keyCommands()
   {
       if(Greenfoot.isKeyDown("left"))
       {
           moveLeft();
       }
       
       if(Greenfoot.isKeyDown("space"))
       {
           ySpeed = -5;
           setImage(balloonRising);
       }
       
       else
       {
            ySpeed = 1;
            setImage(balloon);
       }
   }
   
   private void touchStar()
   {
       ShootingStar star = (ShootingStar) getOneIntersectingObject(ShootingStar.class);
       if(star != null)
       {
           score = score + star.getPoints();
           getWorld().removeObject(star);
       }
   }
   
   public int getScore()
   {
       return score;
   }
   
   public void fall()
   {
       setLocation(getX() , getY() + ySpeed);
   }
   
   public void victory()
   {
       if(score >= 30)
       {
           Greenfoot.setWorld(new Victory());
       }
   }
   
   public void pop()
   {
       if(popped)
       {
           getImage().setTransparency( getImage().getTransparency() - 1 );
           turn(6);
       }
       if(getImage().getTransparency() <= 100)
       {
           Greenfoot.setWorld( new GameOver());
       }
   }
}
